import os
from flask import Flask, render_template, request, redirect, url_for, send_file, request
import numpy as np
from PIL import Image
import trimesh
from scipy.spatial import Delaunay
from scipy.ndimage import gaussian_filter
import subprocess
import re
import time

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'

def extract_last_stream(heic_file, ffmpeg_executable, user_ip):
    # Use ffmpeg to get stream information
    result = subprocess.run([ffmpeg_executable, "-y", "-i", heic_file], stderr=subprocess.PIPE, stdout=subprocess.PIPE)
    output = result.stderr.decode('utf-8')

    # Regular expression to match stream IDs
    stream_pattern = re.compile(r'Stream #0:(\d+)')

    # Extract all stream IDs
    stream_ids = stream_pattern.findall(output)
    
    # Extract the last stream (assuming it's the depth map)
    last_stream_id = stream_ids[-1]
    depth_map_output = os.path.join(app.config['UPLOAD_FOLDER'], f'depth_map_{user_ip}.png')

    # Extract the stream
    subprocess.run([ffmpeg_executable, "-y", "-i", heic_file, "-map", f"0:{last_stream_id}", depth_map_output])

    return depth_map_output

def extract_depth_map_from_dng(dng_file, user_ip):
    # Construct the path to exiftool
    exiftool_path = os.path.join(os.path.dirname(__file__), 'exiftool(-k).exe')

    # Extract depth map using ExifTool
    depth_map_tiff = os.path.join(app.config['UPLOAD_FOLDER'], f'depth_map_{user_ip}.tiff')
    subprocess.run([exiftool_path, '-b', '-SubIFD1:ImageData', dng_file], stdout=open(depth_map_tiff, 'wb'))

    # Convert TIFF to PNG using Pillow
    depth_map_png = os.path.join(app.config['UPLOAD_FOLDER'], f'depth_map_{user_ip}.png')
    with Image.open(depth_map_tiff) as img:
        img.save(depth_map_png)
    
    # Optionally, delete the TIFF file
    os.remove(depth_map_tiff)

    return depth_map_png

def process_depth_map(depth_map_path, user_ip):
    # Load the depth map
    depth_image = Image.open(depth_map_path)

    # Convert the image to grayscale
    depth_image = depth_image.convert('L')

    # Convert the depth image to a NumPy array
    depth_array = np.array(depth_image)

    # Apply Gaussian filter to smooth the depth map
    depth_array = gaussian_filter(depth_array, sigma=2)

    # Normalize the depth map
    depth_array = depth_array.astype(np.float32)
    depth_array = (depth_array - depth_array.min()) / (depth_array.max() - depth_array.min())

    # Generate 3D point cloud from the depth map
    height, width = depth_array.shape
    xx, yy = np.meshgrid(np.arange(0, width), np.arange(0, height))

    # Flip the Y-axis to correct the upside-down orientation
    yy = height - yy

    # Scale the depth values (adjust as needed)
    zz = depth_array * 1000

    # Combine x, y, z coordinates into a point cloud
    points = np.vstack((xx.flatten(), yy.flatten(), zz.flatten())).T

    # Create the Delaunay triangulation of the 2D grid of points
    tri = Delaunay(np.vstack([xx.flatten(), yy.flatten()]).T)

    # Create a Trimesh object
    mesh = trimesh.Trimesh(vertices=points, faces=tri.simplices)

    # Apply Laplacian smoothing to the mesh
    iterations = 2  # Number of smoothing iterations
    mesh = mesh.smoothed(iterations=iterations)

    # Generate a unique OBJ file name
    timestamp = int(time.time())
    obj_output_path = os.path.join(app.config['UPLOAD_FOLDER'], f'model_{user_ip}_{timestamp}.obj')

    # Export the mesh to an OBJ file
    mesh.export(obj_output_path)

    return obj_output_path

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Get user's IP address
        user_ip = request.remote_addr.replace('.', '_')

        # Check if the post request has the file part
        if 'file' not in request.files:
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            return redirect(request.url)
        if file:
            # Save the uploaded file
            uploaded_file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(uploaded_file_path)

            # Determine file type and extract depth map accordingly
            if file.filename.lower().endswith('.heic'):
                ffmpeg_path = os.path.join(os.path.dirname(__file__), 'ffmpeg.exe')
                depth_map_path = extract_last_stream(uploaded_file_path, ffmpeg_path, user_ip)
            elif file.filename.lower().endswith('.dng'):
                depth_map_path = extract_depth_map_from_dng(uploaded_file_path, user_ip)
            else:
                return "Unsupported file format", 400
            
            # Process depth map to generate OBJ
            obj_file_path = process_depth_map(depth_map_path, user_ip)
            
            # Provide download link
            return redirect(url_for('download_file', filename=os.path.basename(obj_file_path)))

    return render_template('index.html')

@app.route('/home')
def home():
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')


@app.route('/uploads/<filename>')
def download_file(filename):
    return send_file(os.path.join(app.config['UPLOAD_FOLDER'], filename), as_attachment=True)

@app.route('/view/<filename>')
def view_file(filename):
    return render_template('view.html', obj_file=filename)

if __name__ == "__main__":
    app.run(debug=True)
